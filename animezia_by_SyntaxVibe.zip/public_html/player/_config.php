<?php 


$websiteTitle = "AnimeZia"; // Website Name
$websiteUrl = "//{$_SERVER['SERVER_NAME']}";  // Website URL
$websiteLogo = $websiteUrl . "https://cdnzia.pages.dev/images/logo.webp"; // Logo
$contactEmail = ""; // Contact Email

$version = "0.4";

//Donate 
$donate = "http://coindrop.to/animezia1";

// Socials 
$telegram = "https://t.me/Animezia_net"; // telegram
$discord = ""; // Discord
$redit = ""; // Reddit
$twitter = ""; // Twitter
 


$disqus = "https://animezia-net.disqus.com"; // Disqus


// API URL
$api = "https://gogo-api-topaz.vercel.app/"; // https://github.com/shashankktiwariii/anikatsu-api


$banner = $websiteUrl . "/files/images/banner.png";  //Banner
?>
